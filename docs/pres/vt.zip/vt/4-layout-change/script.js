
const list = document.querySelector("ul")
const items = document.querySelectorAll("li")
const button = document.querySelector("button")

button.addEventListener("click", husselen)



// regelt het husselen

// STAP 7. Maak de function een async function
async function husselen() {

  /* STAP 2. - START EEN VIEW TRANSITION */

  // Check of VT's ondersteund worden
  // Zo ja, start de VT en roep de functie husselenMaar aan
  // Zo nee, roep de functie husselenMaar direct aan
  // bron: piccalil.li/blog/start-implementing-view-transitions-on-your-websites-today/ (Cyd :)

  // Bonus 🌶️
  // STAP 4. Roep de functie disableButton ook aan na het starten van de VT
  
  // Bonus 🌶️🌶️
  // STAP 6. En roep de functie enableButton aan als de VT klaar is
  // bron: developer.mozilla.org/en-US/docs/Web/API/ViewTransition/finished



  /* JOUW CODE HIER */


  husselenMaar()


}



// husselt de items door elkaar
function husselenMaar() {
  for(let i = 0; i < items.length; i++) {
    let nr =  Math.floor( Math.random() * items.length )
    list.prepend(items[nr]);
  }
}



// disable de button
function disableButton() {
  button.disabled = true;
}



// enable de button
function enableButton() {
  button.disabled = false;
}