const raket = document.querySelector("img")
const button = document.querySelector("button")

button.addEventListener("click", go)

function go() {
  // als view transitions ondersteund worden
  if (document.startViewTransition) {

    // STAP 2. START EEN VIEW TRANSITION

    // https://piccalil.li/blog/start-implementing-view-transitions-on-your-websites-today/
    // voeg dan de class "go" toe aan de raket
    // verander de tekst van de button in "go" (textContent)
    // disable de button (.disabled)

    /* JOUW CODE HIER */




  }
  // anders als view transitions niet ondersteund worden
  else {
    // STAP 3. toon een boodschap met alert() dat VT''s niet worden ondersteund

    /* JOUW CODE HIER */

    

  }
}